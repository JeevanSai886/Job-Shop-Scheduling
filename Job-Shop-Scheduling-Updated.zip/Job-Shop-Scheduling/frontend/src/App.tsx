import { lazy, Suspense, useEffect, useRef, useState } from 'react'
import { Activity, ArrowDownToLine, ArrowRight, BarChart3, BookOpen, Boxes, ChartNoAxesCombined, Check, ChevronRight, CircleHelp, Cpu, Database, FlaskConical, LayoutDashboard, LoaderCircle, Play, Plus, Timer, Upload, X } from 'lucide-react'
import { api, post } from './api'
import { Badge, Empty, fmt, Gantt, Metric, Panel, ResultsTable, SolverFootnote, Workloads } from './components'
import type { Engine, Instance, Objective, Result, Sensitivity, Settings, Stats } from './types'

const SensitivityView = lazy(() => import('./SensitivityView'))

type Page = 'workspace' | 'dataset' | 'sensitivity' | 'methodology'
const pages = [
  { id: 'workspace' as const, name: 'Workspace', icon: LayoutDashboard },
  { id: 'dataset' as const, name: 'Dataset overview', icon: Database },
  { id: 'sensitivity' as const, name: 'Sensitivity analysis', icon: ChartNoAxesCombined },
  { id: 'methodology' as const, name: 'Methodology', icon: BookOpen },
]
const defaultSettings: Settings = { objective: 'makespan', solver: 'cp_sat', time_limit_s: 30 }

export default function App() {
  const [page, setPage] = useState<Page>('workspace')
  const [benchmarks, setBenchmarks] = useState<Instance[]>([])
  const [instance, setInstance] = useState<Instance | null>(null)
  const [stats, setStats] = useState<Stats | null>(null)
  const [settings, setSettings] = useState(defaultSettings)
  const [result, setResult] = useState<Result | null>(null)
  const [sensitivity, setSensitivity] = useState<Sensitivity | null>(null)
  const [busy, setBusy] = useState('')
  const [loading, setLoading] = useState(true)
  const [elapsed, setElapsed] = useState(0)
  const [error, setError] = useState('')
  const [retry, setRetry] = useState(0)
  const [view, setView] = useState('Gantt chart')
  const [deltas, setDeltas] = useState('')
  const [raw, setRaw] = useState('')
  const fileInput = useRef<HTMLInputElement>(null)
  const disabled = Boolean(busy) || loading

  useEffect(() => {
    let current = true
    setLoading(true)
    api<Instance[]>('/benchmarks').then(async data => {
      if (!data.length) throw new Error('No bundled datasets were found. Check the data directory.')
      const initialStats = await api<Stats>(`/instance/${data[0].instance_id}/stats`)
      if (current) { setBenchmarks(data); setInstance(data[0]); setStats(initialStats); setError('') }
    }).catch((err: unknown) => { if (current) setError(err instanceof Error ? err.message : 'Unable to load datasets.') })
      .finally(() => { if (current) setLoading(false) })
    return () => { current = false }
  }, [retry])

  useEffect(() => {
    if (!busy) return
    setElapsed(0)
    const started = Date.now(), timer = window.setInterval(() => setElapsed((Date.now() - started) / 1000), 1000)
    return () => clearInterval(timer)
  }, [busy])

  async function perform(label: string, action: () => Promise<void>) {
    if (disabled) return
    setBusy(label); setError('')
    try { await action() } catch (err) { setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.') }
    finally { setBusy('') }
  }

  async function adopt(next: Instance) {
    const overview = await api<Stats>(`/instance/${next.instance_id}/stats`)
    setInstance(next); setStats(overview); setResult(null); setSensitivity(null)
  }
  function loadBenchmark(name: string) {
    void perform('Loading dataset', async () => adopt(await post<Instance>('/instance', { benchmark: name })))
  }
  function upload(file: File | undefined) {
    if (!file) return
    void perform('Parsing your dataset', async () => {
      if (file.size > 2_000_000) throw new Error('Choose a file smaller than 2 MB.')
      const body = new FormData(); body.append('file', file)
      await adopt(await api<Instance>('/instance', { method: 'POST', body }))
    })
  }
  function validateSettings() {
    if (!Number.isFinite(settings.time_limit_s) || settings.time_limit_s <= 0 || settings.time_limit_s > 300) throw new Error('Set a time limit greater than zero and no more than 300 seconds.')
  }
  function runSolve() {
    if (!instance) return
    void perform('Optimizing schedule', async () => {
      validateSettings()
      const solved = await post<Result>(`/instance/${instance.instance_id}/solve`, settings)
      setResult(solved); setView('Gantt chart')
    })
  }
  function runSensitivity() {
    if (!instance) return
    void perform('Re-solving sensitivity scenarios', async () => {
      validateSettings()
      const values = deltas.split(/[\s,;]+/).filter(Boolean).map(Number)
      if (!values.length || values.length > 20 || values.some(value => !Number.isFinite(value) || value <= -100)) throw new Error('Enter 1–20 finite percentages, each greater than −100, separated by commas or spaces.')
      setSensitivity(await post<Sensitivity>(`/instance/${instance.instance_id}/sensitivity`, { ...settings, deltas: values }))
    })
  }
  function exportResult() {
    if (!result || !instance) return
    const url = URL.createObjectURL(new Blob([JSON.stringify({ instance, result }, null, 2)], { type: 'application/json' }))
    const link = document.createElement('a'); link.href = url; link.download = `${instance.name.replace(/[^\w.-]/g, '_')}-schedule.json`; link.click()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }
  const solved = Boolean(result?.operations.length)
  const source = benchmarks.find(item => item.instance_id === instance?.instance_id) ? 'OR-Library benchmark' : 'Custom dataset'
  const utilization = stats && result?.makespan ? stats.total_processing_time / (stats.num_machines * result.makespan) * 100 : null
  const staleSettings = result && (result.objective !== settings.objective || result.solver !== settings.solver || result.time_limit_s !== settings.time_limit_s)
  const title = pages.find(item => item.id === page)!.name

  return <div className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="#" onClick={e => { e.preventDefault(); setPage('workspace') }} aria-label="Sequence workspace"><span className="brand-symbol"><i /><i /><i /></span><span>sequence<span className="brand-period">.</span></span></a>
      <div className="sidebar-caption">JOB-SHOP SCHEDULING LAB</div>
      <nav aria-label="Main navigation">{pages.map(item => <button key={item.id} className={page === item.id ? 'nav-item selected' : 'nav-item'} onClick={() => setPage(item.id)} aria-current={page === item.id ? 'page' : undefined}><item.icon size={19} />{item.name}{page === item.id && <ChevronRight size={16} className="nav-chevron" />}</button>)}</nav>
      <div className="sidebar-bottom"><div className="sidebar-note"><FlaskConical size={20} /><strong>From data to decisions.</strong><p>Compare schedules. Explore constraints. Find your best sequence.</p><button onClick={() => setPage('methodology')}>Explore the model <ArrowRight size={15} /></button></div><div className="sidebar-footer"><span className="avatar">SQ</span><div>Optimization workspace<small>CP-SAT & MILP</small></div></div></div>
    </aside>

    <div className="main-shell">
      <header className="topbar"><div><span className="topbar-lab">Scheduling lab</span><ChevronRight size={14} /><span>{title}</span></div><a href="https://people.brunel.ac.uk/~mastjjb/jeb/orlib/jobshopinfo.html" target="_blank" rel="noreferrer"><CircleHelp size={16} /><span>Benchmark reference</span></a></header>
      <main>
        <div className="page-heading"><div className="page-heading-text"><div className="eyebrow">OPERATIONS RESEARCH / JOB-SHOP OPTIMIZATION</div><h1>{page === 'workspace' ? 'Scheduling workspace' : title}</h1><p>{page === 'workspace' ? 'Turn machine constraints into an executable schedule.' : page === 'dataset' ? 'Understand the workload before you optimize.' : page === 'sensitivity' ? 'See how processing-time changes affect the entire schedule.' : 'The constraints, objectives, and assumptions behind each schedule.'}</p></div>{page === 'workspace' && <button className="button secondary export-button" disabled={!solved || disabled} onClick={exportResult}><ArrowDownToLine size={16} />Export schedule</button>}</div>

        {error && <div className="error-banner" role="alert"><div><strong>We couldn’t complete that request.</strong><span>{error}</span></div>{!instance && <button className="button secondary" onClick={() => setRetry(value => value + 1)}>Retry connection</button>}<button className="icon-button" aria-label="Dismiss error" onClick={() => setError('')}><X size={18} /></button></div>}

        {page !== 'methodology' && <div className="dataset-strip"><div className="dataset-icon"><Database size={23} /></div><div className="dataset-select"><label htmlFor="instance">ACTIVE DATASET</label><select id="instance" aria-label="Active dataset" disabled={disabled} value={instance?.name ?? ''} onChange={e => loadBenchmark(e.target.value)}>{loading && <option value="">Loading datasets…</option>}{benchmarks.map(item => <option key={item.name} value={item.name}>{item.name.toUpperCase()} · {item.num_jobs} jobs × {item.num_machines} machines</option>)}{instance && !benchmarks.some(item => item.instance_id === instance.instance_id) && <option value={instance.name}>{instance.name}</option>}</select></div><div className="dataset-context"><span>{source}</span>{instance && <small><Check size={13} /> {instance.total_operations} operations validated</small>}</div><button className="button secondary" onClick={() => fileInput.current?.click()} disabled={disabled}><Upload size={16} />Upload instance</button><input ref={fileInput} type="file" accept=".txt,.csv,text/plain,text/csv" className="sr-only" aria-label="Upload instance file" onChange={e => { upload(e.target.files?.[0]); e.target.value = '' }} /></div>}

        {busy && <div className="progress-banner" role="status"><LoaderCircle size={17} className="spin" /><span>{busy} <strong>{fmt(elapsed, 0)}s</strong></span><small>{busy.includes('sensitivity') ? 'Each scenario has its own time budget. Keep this page open.' : 'The search stops at your time limit or when optimality is proven.'}</small></div>}

        {(page === 'workspace' || page === 'sensitivity') && <section className="solver-panel"><div className="solver-panel-title"><Cpu size={19} /><h2>Solver configuration</h2><span>01 / CONFIGURE</span></div><div className="solver-controls"><fieldset disabled={disabled}><legend>Optimization objective</legend><div className="segmented"><button className={settings.objective === 'makespan' ? 'active' : ''} aria-pressed={settings.objective === 'makespan'} onClick={() => setSettings({ ...settings, objective: 'makespan' as Objective })}>Makespan</button><button className={settings.objective === 'idle_time' ? 'active' : ''} aria-pressed={settings.objective === 'idle_time'} onClick={() => setSettings({ ...settings, objective: 'idle_time' as Objective })}>Machine idle time</button></div></fieldset><label>Solver engine<select value={settings.solver} disabled={disabled} onChange={e => setSettings({ ...settings, solver: e.target.value as Engine })}><option value="cp_sat">CP-SAT · recommended</option><option value="pulp_bigm">MILP · PuLP / CBC</option></select></label><label className="time-limit">Time limit <span className="input-unit"><input type="number" min="0.001" max="300" step="any" value={Number.isNaN(settings.time_limit_s) ? '' : settings.time_limit_s} disabled={disabled} onChange={e => setSettings({ ...settings, time_limit_s: e.target.value === '' ? NaN : Number(e.target.value) })} /><span>sec</span></span></label>{page === 'workspace' && <button className="button primary solve-button" disabled={disabled || !instance} onClick={runSolve}>{busy === 'Optimizing schedule' ? <LoaderCircle size={17} className="spin" /> : <Play size={16} fill="currentColor" />}{busy === 'Optimizing schedule' ? 'Solving…' : 'Solve schedule'}</button>}</div><div className="solver-helper"><span>{settings.objective === 'makespan' ? 'Minimize the time at which all jobs are complete.' : 'Minimize waiting and gaps before each machine finishes its last operation.'}</span>{settings.solver === 'pulp_bigm' && <span>CBC can require a longer search for large instances.</span>}</div></section>}

        {page === 'workspace' && <>
          <div className="metric-grid"><Metric label="Makespan" value={fmt(result?.makespan)} sub={solved ? 'Time until every job is complete' : 'Solve to find completion time'} icon={<Timer size={18} />} accent /><Metric label="Total machine idle time" value={fmt(result?.total_idle_time)} sub="Measured until each machine finishes" icon={<Activity size={18} />} /><Metric label="Machine utilization" value={utilization === null ? '—' : `${fmt(utilization, 1)}%`} sub="Across the common makespan horizon" icon={<BarChart3 size={18} />} /><Metric label="Theoretical lower bound" value={fmt(stats?.lower_bound)} sub="From job lengths & machine workloads" icon={<Boxes size={18} />} /></div>
          <Panel title="The schedule" eyebrow="02 / INSPECT" aside={result ? <Badge status={result.status} /> : <span className="badge neutral">Ready to optimize</span>}>
            {result && <div className="result-message" role="status">{result.message}{staleSettings && <strong> Configuration changed. Solve again to apply it.</strong>}</div>}
            {solved && result ? <><div className="result-tabs" role="tablist" aria-label="Schedule view">{['Gantt chart', 'Operations', 'Jobs', 'Sequences'].map(item => <button role="tab" aria-selected={view === item} key={item} className={view === item ? 'active' : ''} onClick={() => setView(item)}>{item}</button>)}<span>{instance?.num_machines} machines · {result.operations.length} operations</span></div>{view === 'Gantt chart' ? <Gantt key={`${instance?.instance_id}-${result.wall_time_s}`} result={result} /> : <ResultsTable result={result} view={view} />}<SolverFootnote result={result} /></> : <Empty><h3>{busy === 'Optimizing schedule' ? 'Finding a feasible sequence…' : 'Your next schedule starts here'}</h3><p>Select an objective and run the solver.<br />The machine timeline will appear here from the computed result.</p><span className="empty-detail">Job precedence + machine capacity, enforced.</span></Empty>}
          </Panel>
          {stats && <div className="bottom-grid"><Panel title="Machine workload" aside={<span className="unit-label">PROCESSING TIME</span>}><Workloads stats={stats} /></Panel><Panel title="Inside this instance" aside={<Database size={18} className="muted" />}><div className="instance-facts"><div><span>Dataset</span><strong>{instance?.name.toUpperCase()}</strong></div><div><span>Jobs / machines</span><strong>{stats.num_jobs} / {stats.num_machines}</strong></div><div><span>Total operations</span><strong>{stats.total_operations}</strong></div><div><span>Total processing time</span><strong>{fmt(stats.total_processing_time)}</strong></div><div><span>Mean operation duration</span><strong>{fmt(stats.processing_times.mean)}</strong></div></div><button className="text-link" onClick={() => setPage('dataset')}>Explore dataset statistics <ArrowRight size={15} /></button></Panel></div>}
        </>}

        {page === 'dataset' && <>
          <details className="paste-panel"><summary><Plus size={16} />Paste an OR-Library instance or CSV</summary><label className="sr-only" htmlFor="raw-instance">Instance text</label><textarea id="raw-instance" value={raw} onChange={e => setRaw(e.target.value)} placeholder="Paste the dimension header and machine/time rows, or CSV with Job,Operation,Machine,ProcessingTime columns." disabled={disabled} /><div><span>UTF-8 · up to 2 MB · zero-based machine indices in OR-Library files</span><button className="button primary" disabled={disabled || !raw.trim()} onClick={() => void perform('Parsing your dataset', async () => adopt(await post<Instance>('/instance', { text: raw, name: 'Pasted instance' })))}>Load text</button></div></details>
          {stats && <><div className="metric-grid"><Metric label="Jobs" value={fmt(stats.num_jobs)} sub={`${stats.total_operations} total operations`} icon={<Boxes size={18} />} /><Metric label="Machines" value={fmt(stats.num_machines)} sub="Exclusive processing resources" icon={<Cpu size={18} />} /><Metric label="Total processing time" value={fmt(stats.total_processing_time)} sub="Sum of all operation durations" icon={<Timer size={18} />} /><Metric label="Makespan lower bound" value={fmt(stats.lower_bound)} sub="Maximum job length or machine load" icon={<BarChart3 size={18} />} accent /></div><Panel title="Processing-time distribution" aside={<span className="unit-label">POPULATION STANDARD DEVIATION</span>}><div className="table-wrap"><table><thead><tr><th>Scope</th><th>Operations</th><th>Workload</th><th>Min</th><th>Max</th><th>Mean</th><th>Std. dev.</th></tr></thead><tbody><tr className="total-row"><td>All operations</td><td>{stats.total_operations}</td><td>{fmt(stats.total_processing_time)}</td><td>{fmt(stats.processing_times.min)}</td><td>{fmt(stats.processing_times.max)}</td><td>{fmt(stats.processing_times.mean)}</td><td>{fmt(stats.processing_times.std)}</td></tr>{stats.machines.map(machine => <tr key={machine.machine}><td>{machine.label}</td><td>{machine.processing_times.count}</td><td>{fmt(machine.workload)}</td><td>{fmt(machine.processing_times.min)}</td><td>{fmt(machine.processing_times.max)}</td><td>{fmt(machine.processing_times.mean)}</td><td>{fmt(machine.processing_times.std)}</td></tr>)}</tbody></table></div></Panel><div className="bottom-grid"><Panel title="Machine workload"><Workloads stats={stats} /></Panel><Panel title="Job routes at a glance"><div className="table-wrap"><table><thead><tr><th>Job</th><th>Operation count</th><th>Total duration</th></tr></thead><tbody>{stats.jobs.map(job => <tr key={job.job}><td>{job.label}</td><td>{job.operation_count}</td><td>{fmt(job.workload)}</td></tr>)}</tbody></table></div></Panel></div></>}
        </>}

        {page === 'sensitivity' && <>
          <Panel title="What changes when processing takes longer?" eyebrow="SCENARIO BUILDER"><div className="scenario-input"><label htmlFor="deltas">Processing-time changes (%)<input id="deltas" value={deltas} disabled={disabled} onChange={e => setDeltas(e.target.value)} placeholder="Enter percentages, separated by commas" /></label><button className="button primary" disabled={disabled || !instance || !deltas.trim()} onClick={runSensitivity}>{busy ? <LoaderCircle size={17} className="spin" /> : <Play size={16} />}Run analysis</button></div><p className="panel-note">Use any positive or negative percentages greater than −100. Every operation changes by the same factor. The baseline and each scenario are solved independently with the settings above.</p></Panel>
          {sensitivity ? <Suspense fallback={<div role="status">Loading scenario chart...</div>}><SensitivityView data={sensitivity} /></Suspense> : <Panel title="Scenario comparison"><Empty><h3>Make room for what-if</h3><p>Add your processing-time changes to compare makespan and machine idle time against a freshly solved baseline.</p></Empty></Panel>}
        </>}

        {page === 'methodology' && <Methodology />}
        <footer className="page-footer"><span>SEQUENCE / JOB-SHOP SCHEDULING LAB</span><span>Every result is computed from your dataset.</span></footer>
      </main>
    </div>
  </div>
}

function Methodology() {
  return <div className="methodology"><Panel title="One scheduling problem. Two exact models." eyebrow="MODEL & ASSUMPTIONS"><p>A job is an ordered route of operations. Each operation runs without interruption on one specified machine. All jobs are available at time zero; a machine processes at most one operation at a time. There are no setup times, release dates, deadlines, or machine calendars in this model.</p><div className="model-flow"><span>Parse & validate</span><ArrowRight /><span>Build constraints</span><ArrowRight /><span>Optimize</span><ArrowRight /><span>Verify the schedule</span></div><p>Job counts, machine counts, routes, durations, workload statistics, and chart geometry all come from the selected or uploaded dataset.</p></Panel><div className="bottom-grid"><Panel title="Decision variables"><dl><dt>Sᵢⱼ ≥ 0</dt><dd>Start of operation j in job i.</dd><dt>Cᵢ = Sᵢ,last + pᵢ,last</dt><dd>Completion of job i; Cₘₐₓ is the latest job completion.</dd><dt>xₐᵦ ∈ {'{0, 1}'}</dt><dd>In the MILP, selects which of two operations on the same machine goes first.</dd><dt>M = Σᵢⱼ pᵢⱼ</dt><dd>A valid horizon computed from the instance; never a fixed problem constant.</dd></dl></Panel><Panel title="Feasibility constraints"><dl><dt>Sᵢ,ⱼ₊₁ ≥ Sᵢⱼ + pᵢⱼ</dt><dd>Respect the operation order within every job.</dd><dt>Sₐ + pₐ ≤ Sᵦ + M(1 − xₐᵦ)</dt><dt>Sᵦ + pᵦ ≤ Sₐ + Mxₐᵦ</dt><dd>Prevent overlaps on a shared machine.</dd><dt>Cₘₐₓ ≥ Cᵢ for every job</dt><dd>Bound the overall completion time.</dd></dl></Panel></div><Panel title="Choose what to minimize"><div className="objective-explanations"><div><span className="number-label">01</span><h3>Makespan</h3><div className="formula">min Cₘₐₓ</div><p>Finish the complete set of jobs as early as possible. The theoretical lower bound is the maximum of the longest job route and the heaviest machine workload.</p></div><div><span className="number-label">02</span><h3>Total machine idle time</h3><div className="formula">min Σₖ (Cₖ − Wₖ)</div><p>Wₖ is fixed machine workload; Cₖ is the latest operation end on that machine. Idle time includes waiting from time zero and internal gaps, ending when that machine finishes. It excludes idle time after its final operation.</p></div></div></Panel><Panel title="Reading results responsibly"><p><strong>CP-SAT</strong> uses interval variables and NoOverlap constraints. <strong>PuLP / CBC</strong> implements the explicit Big-M mixed-integer model. Machine completion is modeled as an exact maximum in both engines. Both return the same result format, verified for operation duration, precedence, and machine exclusivity.</p><p>All finite decimal durations are converted to a common rational time unit derived from the data. Sensitivity changes are applied exactly; processing times are never rounded to whole units. Displayed numbers are rounded only for readability; exported results retain numeric precision.</p><p><strong>Proven optimal</strong> means the solver closed the optimization gap. <strong>Feasible</strong> is a valid incumbent without proof of optimality. A time limit without an incumbent yields no schedule. The best bound and relative gap refer to the selected objective.</p><p>Uniformly scaling every duration scales a proven optimum by the same factor. Sensitivity runs still re-solve each scenario; when proof is missing, search variability can affect comparisons. Utilization uses the common makespan horizon, while the idle-time objective uses each machine’s own completion time.</p><div className="reference-links"><a href="https://people.brunel.ac.uk/~mastjjb/jeb/orlib/jobshopinfo.html" target="_blank" rel="noreferrer">OR-Library benchmark source ↗</a><a href="https://developers.google.com/optimization/scheduling/job_shop" target="_blank" rel="noreferrer">OR-Tools scheduling model ↗</a><a href="https://coin-or.github.io/pulp/" target="_blank" rel="noreferrer">PuLP documentation ↗</a></div></Panel></div>
}
